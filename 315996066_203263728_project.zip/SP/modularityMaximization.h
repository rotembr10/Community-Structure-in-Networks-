

#ifndef SP_PROJECT_MODULARITYMAXIMIZATION_H
#define SP_PROJECT_MODULARITYMAXIMIZATION_H

void Algorithm4(group* g, community* C, double* s);
int calculateScore(double* score, double* s, int* unmoved, int size, community* C ,group* g);
#endif
