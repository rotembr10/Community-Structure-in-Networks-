
/*
 *Iteration over the group O and write all the groups it contains to the output file.
 */
#ifndef SP_READANDWRITE_H
#define SP_READANDWRITE_H
void writeToFile(modularityGroups *O,char* outFile);

#endif
